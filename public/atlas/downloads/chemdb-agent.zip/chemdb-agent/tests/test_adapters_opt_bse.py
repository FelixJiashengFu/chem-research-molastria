"""OPTIMADE（录制回放）+ BSE（本地离线）适配器测试。"""

import vcr

from chemdb_agent.adapters import basis
from chemdb_agent.adapters import optimade as opt

opt_vcr = vcr.VCR(cassette_library_dir="tests/cassettes", record_mode="once")


def test_optimade_search_si_aflow():
    with opt_vcr.use_cassette("opt_aflow_si.yaml"):
        recs = opt.search_structures(elements=["Si"], providers=["aflow"], limit=3)
    assert 1 <= len(recs) <= 3
    rec = recs[0]
    assert rec.record_id.startswith("optimade-aflow:")
    assert rec.is_periodic
    assert set(rec.atoms.get_chemical_symbols()) == {"Si"}
    assert rec.energy is None
    assert rec.source.database == "optimade-aflow"


def test_optimade_search_formula():
    with opt_vcr.use_cassette("opt_aflow_nacl.yaml"):
        recs = opt.search_structures(formula="NaCl", providers=["aflow"], limit=3)
    assert len(recs) >= 1
    assert set(recs[0].atoms.get_chemical_symbols()) == {"Na", "Cl"}


def test_optimade_cod_provider():
    with opt_vcr.use_cassette("opt_cod_si.yaml"):
        recs = opt.search_structures(elements=["Si"], providers=["cod"], limit=2)
    assert len(recs) >= 1
    assert all(r.record_id.startswith("optimade-cod:") for r in recs)


def test_optimade_new_providers_from_navigation():
    # 导航 2026 新增三家（#023 NOMAD / #024 JARVIS / #025 Materials Cloud）
    cases = [
        ("nomad", "opt_nomad_si.yaml"),
        ("jarvis", "opt_jarvis_si.yaml"),
        ("materialscloud", "opt_mc3d_si.yaml"),
    ]
    for provider, cassette in cases:
        with opt_vcr.use_cassette(cassette):
            recs = opt.search_structures(elements=["Si"], providers=[provider], limit=2)
        assert len(recs) >= 1, provider
        assert all(r.record_id.startswith(f"optimade-{provider}:") for r in recs)
        assert all(set(r.atoms.get_chemical_symbols()) == {"Si"} for r in recs)
        assert all(r.energy is None for r in recs)


def test_optimade_get_record_roundtrip():
    with opt_vcr.use_cassette("opt_roundtrip.yaml"):
        recs = opt.search_structures(elements=["Si"], providers=["aflow"], limit=1)
        assert len(recs) == 1
        same = opt.get_record(recs[0].record_id)
    assert same.record_id == recs[0].record_id
    assert same.atoms.get_chemical_symbols() == recs[0].atoms.get_chemical_symbols()


def test_optimade_get_unknown():
    with opt_vcr.use_cassette("opt_unknown.yaml"):
        try:
            opt.get_record("optimade-aflow:definitely-not-an-id-zzz")
        except KeyError as e:
            assert "definitely-not-an-id-zzz" in str(e)
        else:
            raise AssertionError("expected KeyError")


def test_optimade_bad_args():
    for fn in (lambda: opt.search_structures(),
               lambda: opt.search_structures(providers=["nope"]),
               lambda: opt.get_record("mp:mp-149"),
               lambda: opt.get_record("optimade-nope:1")):
        try:
            fn()
        except ValueError:
            pass
        else:
            raise AssertionError("expected ValueError")
    try:
        opt.search_structures(formula="NotAFormula!!")
    except ValueError as e:
        assert "无法解析" in str(e)
    else:
        raise AssertionError("expected ValueError")


def test_bse_orca_def2svp():
    res = basis.get_basis("def2-SVP", ["H", "O"], fmt="orca")
    assert "H" in res.text and "O" in res.text
    assert not res.has_ecp  # 轻元素无 ECP
    assert res.fmt == "orca"


def test_bse_tzvp_ecp_for_pt():
    # 验收任务 3 的预演：Fe/Pt 的 def2-TZVP，Pt 应带 ECP
    res = basis.get_basis("def2-TZVP", ["Fe", "Pt"], fmt="orca")
    assert res.has_ecp
    assert "iron" in res.text.lower() and "platinum" in res.text.lower()  # ORCA 用全名


def test_bse_fmt_mapping():
    res = basis.get_basis("def2-SVP", ["H"], fmt="pyscf")
    assert res.notes and "NWChem" in res.notes[0]
    res = basis.get_basis("def2-SVP", ["H"], fmt="gaussian")
    assert "%" in res.text or "H" in res.text


def test_bse_errors():
    try:
        basis.get_basis("def2-SVP", ["H"], fmt="vasp")
    except ValueError as e:
        assert "未知格式" in str(e)
    else:
        raise AssertionError("expected ValueError")
    try:
        basis.get_basis("def2-SVP", [])
    except ValueError as e:
        assert "不能为空" in str(e)
    else:
        raise AssertionError("expected ValueError")
    try:
        basis.get_basis("not-a-real-basis-xyz", ["H"])
    except ValueError as e:
        assert "取基组失败" in str(e)
    else:
        raise AssertionError("expected ValueError")
