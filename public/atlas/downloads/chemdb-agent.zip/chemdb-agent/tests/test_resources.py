"""资源目录（导航 2026 的 103 条）测试：纯离线。"""

from chemdb_agent.catalog import resources as res


def test_resources_count_and_numbers():
    allr = res.all_resources()
    assert len(allr) == 103
    assert [r["number"] for r in allr] == list(range(1, 104))
    assert all(r["name"] and r["url"].startswith("http") and r["access"] for r in allr)


def test_resources_categories():
    assert len(res.CATEGORIES) == 11
    counts = {c: len(res.by_category(c)) for c in res.CATEGORIES}
    assert counts["综合化合物与化学信息"] == 7
    assert counts["材料与晶体结构"] == 15
    assert counts["软件、平台与计算入口"] == 20
    assert counts["社区与中文入口"] == 4
    assert sum(counts.values()) == 103


def test_resources_integrated_mapping():
    integrated = {r["number"]: r for r in res.integrated()}
    # 已有适配器
    assert integrated[1]["name"] == "PubChem"
    assert integrated[17]["integration"] == "adapter"
    assert integrated[20]["integration"] == "adapter"
    assert integrated[43]["name"] == "ChEMBL"
    # OPTIMADE 五家
    for n in (22, 23, 24, 25, 29):
        assert integrated[n]["integration"] == "optimade", n
    # 其余不得冒充已接入
    assert res.by_number(76)["integration"] == "stub"  # QCArchive 阶段 2 占位
    assert res.by_number(21)["integration"] == "catalog"  # OQMD 端点 502
    assert res.by_number(2)["integration"] == "catalog"  # CAS 订阅


def test_resources_search():
    hits = res.search_resources("NOMAD")
    assert any(r["number"] == 23 for r in hits)
    hits = res.search_resources("", integration="optimade")
    assert len(hits) == 5
    hits = res.search_resources("", category="药物、生物活性与化学空间")
    assert len(hits) == 10 and all(r["category_code"] == "05" for r in hits)
    try:
        res.by_number(999)
    except KeyError:
        pass
    else:
        raise AssertionError("expected KeyError")
