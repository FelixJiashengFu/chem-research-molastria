"""阶段 0 冒烟测试：骨架可导入、服务器可启动、常量正确。

工具调用走 fastmcp 的 MCP 层（mcp.call_tool），与客户端实际调用路径一致。
"""

import asyncio

from chemdb_agent import server, units

EXPECTED_TOOLS = sorted(
    [
        "search_structures",
        "get_record",
        "search_molecules",
        "find_qm_data",
        "get_basis",
        "catalog_status",
        "fetch_dataset_shard",
        "export_training_set",
        "search_resources",
    ]
)


def test_units_constants():
    assert units.HARTREE_TO_EV == 27.211386
    assert units.BOHR_TO_ANGSTROM == 0.529177
    assert units.HARTREE_PER_BOHR_TO_EV_PER_ANGSTROM == 51.42207


def test_nine_tools_registered():
    tools = asyncio.run(server.mcp.list_tools())
    assert sorted(t.name for t in tools) == EXPECTED_TOOLS


def test_catalog_status_ok(tmp_path, monkeypatch):
    monkeypatch.setattr(server, "DATA_DIR", tmp_path)
    res = asyncio.run(server.mcp.call_tool("catalog_status", {}))
    assert not res.is_error
    assert res.structured_content["status"] == "ok"
    assert res.structured_content["data_dir"] == str(tmp_path)


def test_search_resources_tool():
    res = asyncio.run(server.mcp.call_tool("search_resources", {"integration": "optimade"}))
    assert not res.is_error
    assert res.structured_content["count"] == 5
    names = {r["name"] for r in res.structured_content["results"]}
    assert {"AFLOW", "NOMAD", "JARVIS", "Materials Cloud"} <= names


def test_placeholders_report_stage():
    res = asyncio.run(server.mcp.call_tool("search_structures", {"formula": "LiMnO2"}))
    assert res.structured_content["status"] == "not_implemented"
    assert "阶段 1" in res.structured_content["message"]
    res = asyncio.run(server.mcp.call_tool("export_training_set", {"record_ids": ["mp:mp-149"]}))
    assert res.structured_content["status"] == "not_implemented"
    assert "阶段 3" in res.structured_content["message"]
