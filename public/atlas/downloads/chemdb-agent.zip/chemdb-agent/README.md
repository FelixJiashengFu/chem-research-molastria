# chemdb-agent

计算化学数据库 Agent：用自然语言跨库检索晶体/分子结构与计算数据，
统一单位与理论级别后导出 ASE 数据库，直接交给 SchNetPack 或 MACE 训练。

实施计划见 `docs/`（原文 docx ）——本文只写“怎么跑起来”。

## 阶段 0（第 1 周）：环境与骨架 ✅

- WSL Ubuntu + `uv` 管理环境，Python 3.11
- 跑通 MP 官方 MCP 服务器并接入 Claude
- 申请 API key 与 HF 访问

### 1. 准备 WSL 环境

```bash
# 在 WSL Ubuntu 里
cd /mnt/k/Redshift/chemdb-agent
uv python install 3.11
uv sync --python 3.11
```

### 2. 填 API key

```bash
cp .env.example .env
# 编辑 .env，填入 MP_API_KEY（必填）、HF_TOKEN（P1 阶段用）
```

- MP API key：<https://next-gen.materialsproject.org/api>（免费，需注册）
- Hugging Face：<https://huggingface.co> 注册，OMol25 在其数据集页点 “Request access”

### 3. 验证：MP 官方 MCP 服务器

```bash
# 5 个工具：search、fetch、fetch_many、fetch_all、get_phase_diagram_from_elements
uv run --python 3.11 mpmcp --help
# 或用本仓库的冒烟测试（列出双方工具，无需 API key）
uv run --python 3.11 pytest tests/ -v
```

> 无 API key 也能列出工具；真实查询需要 `MP_API_KEY`。

### 4. 接入 Claude（Claude Desktop / Claude Code）

在 MCP 客户端配置里加：

```json
{
  "mcpServers": {
    "mp": {
      "command": "wsl",
      "args": ["bash", "-lc", "cd /mnt/k/Redshift/chemdb-agent && uv run --python 3.11 mpmcp"],
      "env": { "MP_API_KEY": "你的key" }
    },
    "chemdb-agent": {
      "command": "wsl",
      "args": ["bash", "-lc", "cd /mnt/k/Redshift/chemdb-agent && uv run --python 3.11 python -m chemdb_agent.server"],
      "env": { "MP_API_KEY": "你的key" }
    }
  }
}
```

同款配置另存一份在 `mcp-config.example.json`，复制后把 `你的key` 换成真实 key 即可用。

注意：`chemdb-agent` 自己的 8 个工具在阶段 1–3 才逐个实现；
阶段 0 只保证服务器能启动、`catalog_status` 可用，其余工具返回“未实现”占位。

## 仓库结构

```
chemdb-agent/
├── pyproject.toml
├── .env.example
├── src/chemdb_agent/
│   ├── server.py        # fastmcp 入口，注册全部工具
│   ├── schema.py        # 统一记录（阶段 1 实现）
│   ├── units.py         # 单位换算、理论级别规范化（阶段 1 实现）
│   ├── adapters/        # 各数据源适配器（阶段 1–2 实现）
│   ├── catalog/         # DuckDB 索引与分片下载器（阶段 2 实现）
│   └── export.py        # ASE db / extxyz + manifest（阶段 3 实现）
├── data/                # 本地数据（git 忽略）
└── tests/
```

## 路线图

- 阶段 0（第 1 周）：环境与骨架 ← 本周
- 阶段 1（第 2–3 周）：统一模型、单位换算与单测；OPTIMADE、MP、PubChem、BSE 四个适配器
- 关卡 1（第 3 周末）：在 Claude 里能调用 OPTIMADE 与 MP 查询
- 阶段 2（第 4–5 周）：QCArchive 适配器；DuckDB 目录与按需下载；理论级别规范化与去重
- 阶段 3（第 6 周）：export_training_set 与 manifest；3 个端到端验收任务
- 关卡 2（第 6 周末）：3 个端到端任务全部通过
- 阶段 4（第 7–8 周）：JARVIS、Alexandria、MatPES、OMol25 子集；使用文档；接通 SchNetPack
