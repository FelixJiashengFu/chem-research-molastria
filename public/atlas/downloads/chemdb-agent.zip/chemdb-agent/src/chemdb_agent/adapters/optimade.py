"""OPTIMADE 适配器（AFLOW、COD 等）。

- 一次查询多个库，返回统一记录（纯结构：能量为 None，进不了训练集）。
- 部分占据位点取首个元素并在 extras 标注 ``partial_occupancy``。
- 端点状态（2026-10-27 实测）：AFLOW、COD、NOMAD、JARVIS、Materials Cloud
  （MC3D 子库）的 /v1 可用；OQMD 端点仍 502，未接入。
"""

from __future__ import annotations

from collections import defaultdict
from typing import Any

import requests
from ase import Atoms
from optimade.client import OptimadeClient
from pymatgen.core import Composition

from chemdb_agent.schema import LevelOfTheory, Source, UnifiedRecord

PROVIDERS: dict[str, str] = {
    # 注意：OptimadeClient 会自己拼 /v1，这里不要带版本号
    "aflow": "https://aflow.org/API/optimade",
    "cod": "https://www.crystallography.net/cod/optimade",
    # 2026-10-27 据《计算化学数据库与资源导航 2026》新增，端点均实测 200：
    # NOMAD 的版本段已在路径里（/prod/v1/optimade），客户端再拼 /v1 服务器亦可接受
    "nomad": "https://nomad-lab.eu/prod/v1/optimade",
    "jarvis": "https://jarvis.nist.gov/optimade/jarvisdft",
    # Materials Cloud 本体是索引元数据库，结构取其 MC3D（PBE-v1）子库
    "materialscloud": "https://optimade.materialscloud.org/main/mc3d-pbe-v1",
}

LICENSES: dict[str, str] = {
    "aflow": "AFLOW-ToU",
    "cod": "CC0-1.0",
}

# 必须显式点名：COD 默认列表响应不带坐标（实测 2026-10-27），要了才给；
# AFLOW 照单全收。只用 v1.0/v1.1 标准字段，两家 api_version 都是 1.1.0。
RESPONSE_FIELDS: list[str] = [
    "elements",
    "nelements",
    "elements_ratios",
    "chemical_formula_reduced",
    "chemical_formula_hill",
    "dimension_types",
    "nperiodic_dimensions",
    "nsites",
    "lattice_vectors",
    "cartesian_site_positions",
    "species_at_sites",
    "species",
]


def _build_filter(
    formula: str | None, elements: list[str] | None, entry_id: str | None
) -> str:
    if entry_id is not None:
        return f'id="{entry_id}"'
    if formula is not None:
        try:
            comp = Composition(formula)
        except Exception as e:
            raise ValueError(f"化学式 {formula!r} 无法解析：{e}") from e
        elements = sorted(str(el) for el in comp.elements)
    if not elements:
        raise ValueError("请至少给出 formula、elements、entry_id 中的一个")
    quoted = ", ".join(f'"{el}"' for el in elements)
    return f"elements HAS ALL {quoted} AND nelements={len(elements)}"


def _attributes_to_atoms(a: dict[str, Any]) -> tuple[Atoms, bool]:
    """OPTIMADE 属性 → ASE Atoms。返回 (atoms, 是否含部分占据)。"""
    species = {sp["name"]: sp.get("chemical_symbols", [sp["name"]]) for sp in a.get("species", [])}
    symbols: list[str] = []
    partial = False
    for site in a.get("species_at_sites", []):
        syms = species.get(site, [site])
        symbols.append(syms[0])
        if len(syms) > 1:
            partial = True
    for sp in a.get("species", []):
        conc = sp.get("concentration", [1.0])
        if any(c < 1.0 - 1e-9 for c in conc):
            partial = True
    positions = a.get("cartesian_site_positions", [])
    if len(symbols) != len(positions):
        raise ValueError(
            f"位点数不一致：{len(symbols)} 个 species_at_sites 对 {len(positions)} 组坐标"
        )
    cell = a.get("lattice_vectors")
    dim_types = a.get("dimension_types") or [1, 1, 1]
    pbc = [bool(d) for d in dim_types[:3]]
    return Atoms(symbols=symbols, positions=positions, cell=cell, pbc=pbc), partial


def _to_record(provider: str, item: dict[str, Any]) -> UnifiedRecord:
    a = item.get("attributes", item)
    entry_id = str(item.get("id", "?"))
    atoms, partial = _attributes_to_atoms(a)
    if not atoms.pbc.any():
        # 分子/团簇条目：统一记录要求分子必须给 charge/multiplicity，
        # 材料库不提供这两个量，不能瞎填——明确报错，由检索层跳过。
        raise ValueError(f"非周期条目（{entry_id}）：dimension_types 全 0，不是晶体结构")
    base_url = PROVIDERS[provider]
    return UnifiedRecord.from_atoms(
        atoms,
        record_id=f"optimade-{provider}:{entry_id}",
        level_of_theory=LevelOfTheory(method="unknown", spin="unknown"),
        source=Source(
            database=f"optimade-{provider}",
            url=f"{base_url}/v1/structures/{entry_id}",
        ),
        license=LICENSES.get(provider, "see-provider-terms"),
        raw_units={"length": "Angstrom"},
        extras={
            "formula_reduced": a.get("chemical_formula_reduced"),
            "formula_hill": a.get("chemical_formula_hill"),
            "nsites": a.get("nsites"),
            "partial_occupancy": partial,
        },
    )


def _query(provider: str, optimade_filter: str, limit: int) -> list[dict[str, Any]]:
    client = OptimadeClient(
        base_urls=[PROVIDERS[provider]],
        http_client=requests.Session,
        max_results_per_provider=limit,
        silent=True,
    )
    # OptimadeClient.all_results 是类级 defaultdict，不隔离会跨查询累积
    # （常驻 MCP 进程里越查越多）：实例级影子 + 只读本次返回值。
    client.all_results = defaultdict(dict)
    try:
        results = client.get(optimade_filter, response_fields=RESPONSE_FIELDS)
    except Exception as e:
        raise ConnectionError(f"OPTIMADE 提供方 {provider} 查询失败：{e}") from e
    items: list[dict[str, Any]] = []
    _collect_structures(results, items)
    if not items:
        errors: list[Any] = []
        _collect_errors(results, errors)
        # errors 里混着两种东西：提供方返回的错误对象（dict，OPTIMADE 规范）
        # 和客户端自己加的纯字符串（目前只有空页带 next 链接时的
        # "Detected potential infinite loop"，对我们就是"没查到"）。
        # 只有 dict 才算真报错；HTTP 层失败早已由客户端抛 RuntimeError。
        real = [e for e in errors if isinstance(e, dict)]
        if real:
            raise ConnectionError(f"OPTIMADE 提供方 {provider} 报错：{real[0]}")
    return items[:limit]


def _collect_errors(node: Any, out: list[Any]) -> None:
    """收集响应里的 errors（客户端 silent=True 会吞掉，必须自己看）。"""
    if isinstance(node, dict):
        for k, v in node.items():
            if k == "errors" and v:
                out.extend(v if isinstance(v, list) else [v])
            else:
                _collect_errors(v, out)
    elif isinstance(node, list):
        for v in node:
            _collect_errors(v, out)


def _collect_structures(node: Any, out: list[dict[str, Any]]) -> None:
    """递归收集形如结构资源的节点（有 attributes + id），兼容客户端的嵌套。

    get() 返回的是 asdict 后的纯 dict；直读 all_results 时底层是客户端
    自带的 QueryResults 容器（有 .data、无 model_dump），这里两种都兼容。
    """
    if hasattr(node, "model_dump"):
        node = node.model_dump()
    elif hasattr(node, "data") and not isinstance(node, (dict, list, str, bytes)):
        # optimade-client 自带的 QueryResults 容器（非 pydantic）：取 .data
        node = node.data
    if isinstance(node, dict):
        if "attributes" in node and "id" in node:
            out.append(node)
            return
        for v in node.values():
            _collect_structures(v, out)
    elif isinstance(node, list):
        for v in node:
            _collect_structures(v, out)


def search_structures(
    formula: str | None = None,
    elements: list[str] | None = None,
    providers: tuple[str, ...] | list[str] = ("aflow", "cod"),
    limit: int = 50,
) -> list[UnifiedRecord]:
    """跨 OPTIMADE 提供方查晶体结构（纯结构记录，无能量）。"""
    unknown = [p for p in providers if p not in PROVIDERS]
    if unknown:
        raise ValueError(f"未知 OPTIMADE 提供方 {unknown}，可选：{sorted(PROVIDERS)}")
    optimade_filter = _build_filter(formula, elements, None)
    per = max(1, limit // max(1, len(providers)))
    records: list[UnifiedRecord] = []
    for provider in providers:
        # NOMAD 混有分子/团簇条目（dimension_types 全 0），只取周期结构；
        # dimension_types 本身在 NOMAD 不可检索（实测 400），用
        # nperiodic_dimensions>=1（含 2D 材料）。其余提供方本身都是晶体库，
        # 不加此条以免改变已录制的查询。
        query_filter = optimade_filter
        if provider == "nomad":
            query_filter += " AND nperiodic_dimensions>=1"
        for item in _query(provider, query_filter, per):
            try:
                records.append(_to_record(provider, item))
            except ValueError as e:
                if "非周期条目" in str(e):
                    continue  # 防御：个别提供方混入的团簇条目跳过，不冒充晶体
                raise ValueError(f"提供方 {provider} 的条目无法转换：{e}") from e
    return records[:limit]


def get_record(record_id: str) -> UnifiedRecord:
    """按 optimade-<provider>:<id> 取单条记录。"""
    prefix, sep, entry_id = record_id.partition(":")
    if not sep or not prefix.startswith("optimade-"):
        raise ValueError(f"record_id 须形如 optimade-aflow:<id>，实际 {record_id!r}")
    provider = prefix.removeprefix("optimade-")
    if provider not in PROVIDERS:
        raise ValueError(f"未知 OPTIMADE 提供方 {provider!r}，可选：{sorted(PROVIDERS)}")
    items = _query(provider, _build_filter(None, None, entry_id), 1)
    if not items:
        raise KeyError(f"{provider} 里找不到 {entry_id}")
    return _to_record(provider, items[0])
