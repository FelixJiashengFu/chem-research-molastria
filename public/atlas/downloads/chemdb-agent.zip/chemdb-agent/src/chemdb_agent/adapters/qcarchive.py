"""QCArchive 适配器（qcportal，只读 MolSSI 公共服务器）——阶段 2 实现。"""
