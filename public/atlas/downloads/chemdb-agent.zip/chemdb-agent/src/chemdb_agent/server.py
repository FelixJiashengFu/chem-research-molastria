"""chemdb-agent MCP 服务器入口（fastmcp）。

阶段 0：服务器能启动、`catalog_status` 可用；其余 7 个工具为占位，
在阶段 1–3 随适配器/统一化层/导出层逐个实现。
"""

from __future__ import annotations

import os
from pathlib import Path
from typing import Any, Literal

from fastmcp import FastMCP

mcp = FastMCP("chemdb-agent")

DATA_DIR = Path(os.environ.get("CHEMDB_DATA_DIR", Path(__file__).resolve().parents[2] / "data"))

_STAGE = {
    "search_structures": "阶段 1（第 2–3 周，随 OPTIMADE/MP 适配器）",
    "get_record": "阶段 1（第 2–3 周，随统一记录与缓存）",
    "search_molecules": "阶段 1（第 2–3 周，随 PubChem 适配器）",
    "find_qm_data": "阶段 2（第 4–5 周，随 QCArchive 适配器与本地目录）",
    "get_basis": "阶段 1（第 2–3 周，随 BSE 适配器）",
    "fetch_dataset_shard": "阶段 2（第 4–5 周，随 DuckDB 目录与分片下载器）",
    "export_training_set": "阶段 3（第 6 周，随导出层）",
}


def _placeholder(tool: str) -> dict[str, Any]:
    return {
        "status": "not_implemented",
        "tool": tool,
        "message": f"{tool} 在{_STAGE[tool]}实现，当前为阶段 0 骨架占位。",
    }


@mcp.tool()
def search_structures(
    formula: str | None = None,
    elements: list[str] | None = None,
    databases: list[str] | None = None,
    limit: int = 50,
) -> dict[str, Any]:
    """跨库检索晶体结构（OPTIMADE、MP）。默认最多 50 条摘要。"""
    return _placeholder("search_structures")


@mcp.tool()
def get_record(record_id: str) -> dict[str, Any]:
    """按 record_id 取完整统一记录（如 mp:mp-149）。结果缓存。"""
    return _placeholder("get_record")


@mcp.tool()
def search_molecules(query: str, by: Literal["name", "smiles", "inchikey"] = "name") -> dict[str, Any]:
    """按名称/SMILES/InChIKey 查分子（PubChem）。遵守限速。"""
    return _placeholder("search_molecules")


@mcp.tool()
def find_qm_data(
    elements: list[str] | None = None,
    substructure_smiles: str | None = None,
    level_of_theory: str | None = None,
) -> dict[str, Any]:
    """找 QM 数据集：只返回统计和样本，不拉全量。"""
    return _placeholder("find_qm_data")


@mcp.tool()
def get_basis(basis_name: str, elements: list[str], fmt: str = "orca") -> dict[str, Any]:
    """取基组与 ECP 文本（BSE，离线）。"""
    return _placeholder("get_basis")


@mcp.tool()
def search_resources(
    query: str = "",
    category: str | None = None,
    integration: str | None = None,
) -> dict[str, Any]:
    """检索资源目录（《计算化学数据库与资源导航 2026》103 条）。

    integration 可选 adapter / optimade / stub / catalog；catalog 表示仅收录
    导航信息、尚未接入，不会冒充可检索数据源。
    """
    from chemdb_agent.catalog.resources import search_resources as _search

    results = _search(query, category=category, integration=integration)
    return {"status": "ok", "count": len(results), "results": results}


@mcp.tool()
def catalog_status() -> dict[str, Any]:
    """本地已有数据集、版本、大小、许可（只读）。阶段 0 即可用。"""
    from chemdb_agent.catalog.resources import RESOURCES, integrated

    DATA_DIR.mkdir(parents=True, exist_ok=True)
    entries = [
        {"name": p.name, "size_bytes": p.stat().st_size if p.is_file() else None}
        for p in sorted(DATA_DIR.iterdir())
        if p.name != ".gitkeep"
    ]
    return {
        "status": "ok",
        "data_dir": str(DATA_DIR),
        "entries": entries,
        "resources": {
            "total": len(RESOURCES),
            "integrated": [r["name"] for r in integrated()],
            "source": "《计算化学数据库与资源导航 2026》（103 条，2026-10-27 核验）",
        },
    }


@mcp.tool()
def fetch_dataset_shard(dataset: str, filt: str = "") -> dict[str, Any]:
    """下载数据集分片到本地目录。超过 2 GB 先返回估计大小，确认后才下载。"""
    return _placeholder("fetch_dataset_shard")


@mcp.tool()
def export_training_set(
    record_ids: list[str] | None = None,
    query: str | None = None,
    fmt: Literal["ase_db", "extxyz"] = "ase_db",
    path: str = "train.db",
) -> dict[str, Any]:
    """导出训练集 + manifest.json。理论级别不一致或许可冲突时拒绝并说明原因。"""
    return _placeholder("export_training_set")


def main() -> None:
    mcp.run()


if __name__ == "__main__":
    main()
