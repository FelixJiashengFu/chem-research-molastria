"""导出 ASE db / extxyz + manifest（export.py）——阶段 3 实现。"""

from __future__ import annotations


def export_training_set(*args, **kwargs):
    raise NotImplementedError("export.py 在阶段 3（第 6 周）实现")
